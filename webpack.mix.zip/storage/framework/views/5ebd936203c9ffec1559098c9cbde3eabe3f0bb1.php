<?php $__env->startSection('content'); ?>
    
    <div class="container">


        <div class="form-group">
            <label for="usr">Title:</label>
            <?php echo e($article->title); ?>

        </div>
        <div class="form-group">
            <label for="usr">body:</label>
            <?php echo e($article->body); ?>

        </div>

        <div class="form-group">

            <table class="table table-striped">
                <tr>
                    <td> comments</td>
                </tr>

                <?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>  <?php echo e($c->comment); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

            <form action="/read/<?php echo e($article->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="usr">body:</label>
                    <textarea rows="4" cols="50"  name="body" class="form-control">
                    </textarea>
                </div>

                
                <input type="submit" value="add comment" class="btn btn-primary"/>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybloger\resources\views/manage/read.blade.php ENDPATH**/ ?>